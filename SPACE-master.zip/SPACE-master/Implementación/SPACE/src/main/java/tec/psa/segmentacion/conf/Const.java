package tec.psa.segmentacion.conf;

/**
 * Clase con valores constantes.
 * 
 * @author Joel
 *
 */
public class Const {

  public static int LIMITE = 256;
  
  public static String IMG_DIR =
      "C:/Users/Joel/Dropbox/I Semestre 2017/Aseguramiento de la Calidad del Software"
      + "/Proyectos/Archivos de proyecto/input/groundtruth/";

}
