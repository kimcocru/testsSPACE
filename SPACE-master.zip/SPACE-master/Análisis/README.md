﻿1.0.0
 
 Items de configuracion - Análisis
